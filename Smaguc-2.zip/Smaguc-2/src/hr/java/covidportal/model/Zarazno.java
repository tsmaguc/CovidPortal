package hr.java.covidportal.model;

public interface Zarazno {

    public void prelazakZarazeNaOsobu(Osoba osoba);
}
